#include<iostream>
#include<fstream>
#include<sstream>

using namespace std;

class item
{
    public:
    
    
     int item_id;
     string item_name;
     string description;
     int quantity;
     float price;
     
     
     item(int id , string name , string des , int q , float pr) : item_id (id) ,  item_name (name) ,  description  (des) ,  quantity (q) ,  price (pr)   {   }
          
    item ()
    {
    }
     
     void display()
     {
        cout<<"\n\t------ ITEM --------\n";
        cout<<"ID of item is : "<<item_id<<endl
        <<"Name of item is : "<<item_name<<endl
        <<"Description is : "<<description<<endl;
        if(quantity < 3 )
             {
                cout<<"\033[31m ITEM Quantity IS    : "<<quantity    << " \033[0m"<<endl;
             }
             
             else 
             {
              cout<<"ITEM Quantity IS    : "<<quantity    << " "<<endl;
             }
        
        cout<<"Price of item is : "<<price<<endl<<endl;
     }
};

class treenode 
{   
public:
    treenode* left; // left child of node 
    treenode* right; // right child of node 
    
    item data; // item 
    
    treenode() 
      { 
           left  = NULL;
           right = NULL ;
      }
     
    
    
    
};


class InventoryTree
{

public:

    treenode* root; // root containig left right child and item 
     
     InventoryTree()
     {
         root = NULL;
     }
     
     bool isempty()
     {
       if( root==NULL)
       {
           return true;
       }
       
       else
       {
         return false;
       }
     }
     
  //-----------------------INSERTION FUNCTION ---------------------   
     void insertItem(item t1)
     {
         treenode* temp = new treenode;
         temp->data = t1;
         
         if( isempty())
         {
             root = temp;
         }
         
         else
         {
           treenode* temp1 = root;
            while(true)
            {
               if( temp->data.item_id == temp1->data.item_id)
               {
                   cout<<"\nItem id should be unique : please reenter item having unique id \n";
                   break;
               }
               
               else if ( temp1->data.item_id > temp->data.item_id)
               {
                   if( temp1->left == NULL)
                   {
                      temp1->left = temp; 
                      return ;
                   }
                   temp1 = temp1->left;
               }
               else if (temp1->data.item_id < temp->data.item_id)
               {
                   if( temp1->right == NULL)
                   {
                      temp1->right = temp; 
                      return ;
                   }
                   temp1 = temp1->right;
               }
            }
         }
     }
     
     
    //------------------ FUNCTION FOR TRAVERSAL (INORDER) -------------------------------
    
    void inorderToDisplay(treenode* p) 
    {
        if (p != NULL) 
        {
             inorderToDisplay(p->left);
             cout<<"ITEM ID IS          : "<<p->data.item_id     << " "<<endl;
             cout<<"ITEM Name IS        : "<< p->data.item_name  << " "<<endl;
             cout<<"ITEM Description IS : "<<p->data.description << " "<<endl;
             if(p->data.quantity < 3 )
             {
                cout<<"\033[31m ITEM Quantity IS    : "<<p->data.quantity    << " \033[0m"<<endl;
             }
             
             else 
             {
              cout<<"ITEM Quantity IS    : "<<p->data.quantity    << " "<<endl;
             }
             cout<<"ITEM Price IS       : "<<p->data.price       << " "<<endl;
             cout<<">>--------------------------<<"<<endl<<endl;
             inorderToDisplay(p->right);
        }
    }
    
    
  //--------------------- TWO FUNCTIONS TO SEARCH ITEM UNIQUENESS --------------------------
  
     bool searchid(int id)
     {
         return serachidrecurcively(root ,  id);
     }
     
     bool serachidrecurcively(treenode* p , int id)
     {
          if( p == NULL)
          {
            
            return false;
          }
          
          else if( p->data.item_id == id)
          {
           return true;
          }
          
          else 
          {
          
             if( p->data.item_id < id)
             {
               return serachidrecurcively(p->right , id);
                
             }
             
             else 
             {
                 if( p->data.item_id > id)
             {
               return serachidrecurcively(p->left , id);
                
             }
             }
          }
          return false;
     }
   //----------------------TWO Functions to search item ------------------------- 
     bool  searchItem(int id) 
     {
       return searchITEM(root , id);
     }
     
    bool searchITEM(treenode*p , int id)
     {
       if( p == NULL)
       {
         
         return false;
       }
        
        else if( p->data.item_id == id)
        {
        
           cout<<"\n----ITEM FOUND----\n";
           return true;
        }
        
        else 
        {
            if( id < p->data.item_id)
            {
              return searchITEM(p->left , id);
            }
            else if( id > p->data.item_id)
            {
              return searchITEM(p->right , id);
            }
        }
        
       return false;  
     }
     //------------------Functions to search and return node to update ------------------
     
    
treenode* searchItemforUpdate(int id) {
    return searchITEMforUpdate(root, id);
}

treenode* searchITEMforUpdate(treenode* p, int id) {
    if (p == NULL) {
        return NULL;
    } else if (p->data.item_id == id) {
        return p;
    } else {
        if (id < p->data.item_id) {
            return searchITEMforUpdate(p->left, id);
        } else {
            return searchITEMforUpdate(p->right, id);
        }
    }
}
     
     //----------Function to update quantity-------------
     
     void updateQuantity( treenode * node , int q)
     {
         node->data.quantity = q;
         
     }
     
     //----------Function to update Price-------------
     
     void updateQuantity( treenode * node , float p)
     {
         node->data.price = p;
         
     }
     
    
     
     
     void checkstockAvailability()
     {
     int id;
        cout<<"\nEnter the id of item you want to update : ";
        cin>>id;
        cout<<endl;
        treenode * getnode = NULL;
        getnode =  searchItemforUpdate(id);
        
        if( getnode!=NULL)
         {
           cout<<"\n\t\t\t\033[36m The Units of Item Available is :\033[0m "<<getnode->data.quantity<<endl;
         }
         
         else
         {
          cout<<"\nNO item Available";
         }
     }
     
     void itemslowinstock(treenode * p) // recieves root
     {
     int count =0;
         if(p == NULL)
         {
           return;
         }
         
         if( p->data.quantity < 3 )
         {
          
          cout<<"\n\t\t\t\t\033[32m -------ITEM WHICH IS LOW IN STOCK-------- \033[0m\n ";
          
            p->data.display();
            
            
         }
         
         
         itemslowinstock(p->left);
         itemslowinstock(p->right);
         
        
     }
     
     void restock(int id , int num)
     {
     treenode* get = NULL;
          get = searchITEMforUpdate(root,  id);
          if( get!= NULL)
          {
              get->data.quantity = get->data.quantity + num;
              cout<<"\n\t\t\t\t\t\033[32m ------Item Restocked Successfully------\033[0m\n ";
              get->data.display();
          }
          
         else 
         {
           cout<<"\nNO item found\n";
           return;
         }
     }
     
    void itemsWithPriceRange(treenode* p) 
    {
    if (p != NULL) 
    {
        
        if (p->data.price > 1000 && p->data.price < 100000)
         {
            p->data.display();
        }

        
        itemsWithPriceRange(p->left);
        itemsWithPriceRange(p->right);
    }
}

void lowestPriceItem() 
{
    if (root == NULL) 
    {
        cout << "\n\t\t\t\tWarehouse is empty." << endl;
        return;
    }

    treenode* temp = root;

   
    while (temp->left != NULL) 
    {
        temp = temp->left;
    }

    cout << "\n\t\t\t\tCheapest Item In the Warehouse is : " << endl;
    temp->data.display();
}

  void expensiveItem() 
  {
    if (root == NULL) 
    {
        cout << "\n\t\t\t\tWarehouse is empty." << endl;
        return;
    }

    treenode* temp = root;

   
    while (temp->right != NULL) 
    {
        temp = temp->right;
    }

    cout << "\n\t\t\t\tMost Expensive Item In the Warehouse is : " << endl;
    temp->data.display();
}




void bulkinsertion(string filePath) 
{
    ifstream file(filePath);
    string line;
    
    if (!file.is_open()) 
    {
        cout << "Error opening file." << endl;
        return;
    }
    
    while (getline(file, line)) 
    {
        istringstream lineStream(line);
        string temp;
        int id, quantity;
        double price;
        string name, description;

        if (!getline(lineStream, temp, ',')) 
            continue;
        
        id = atoi(temp.c_str());

        if (!getline(lineStream, name, ',')) 
            continue;

        if (!getline(lineStream, description, ',')) 
            continue;

        if (!getline(lineStream, temp, ',')) 
            continue;

        quantity = atoi(temp.c_str());

        if (!getline(lineStream, temp)) 
            continue;

        price = atof(temp.c_str());

       
        treenode* existingNode = searchItemforUpdate(id);
        
        if (existingNode) 
        {
            
            existingNode->data.item_name = name;
            existingNode->data.description = description;
            existingNode->data.quantity = quantity;
            existingNode->data.price = price;
        } 
        else 
        {
           
            item newItem(id, name, description, quantity, price);
            insertItem(newItem);
        }
    }
    
    file.close();
}

treenode* findParent(treenode* root, int id) 
{
    treenode* parent = nullptr;
    treenode* current = root;

    while (current != nullptr && current->data.item_id != id) 
    {
        parent = current;
        if (id < current->data.item_id) 
        {
            current = current->left;
        } else {
            current = current->right;
        }
    }

    return parent;
}

void makeDeletion(treenode *&nodePtr) 
{
    treenode *tempNodePtr; 

    
    if (nodePtr->right == NULL) 
    { 
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->left; 
        delete tempNodePtr;
    }
    
    else if (nodePtr->left == NULL) 
    {
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->right; 
        delete tempNodePtr;
    }
    
    else 
    {
        
        tempNodePtr = nodePtr->right;
        treenode *parent = nodePtr; 

        while (tempNodePtr->left != NULL) 
        {
            parent = tempNodePtr;
            tempNodePtr = tempNodePtr->left;
        }

        
        nodePtr->data = tempNodePtr->data;

        
        if (parent->left == tempNodePtr)
            parent->left = tempNodePtr->right;
        else
            parent->right = tempNodePtr->right;

        delete tempNodePtr; 
    }
}
};

int main()
{
int id ;


    cout << "\n\n\t\t\t\t\t\t\033[35m*************************************************************************************\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                            ---DATA STRUCTURES---                            \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ASSIGNMENT NO . 2                              \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                 LAIBA NASIR                                 \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ROLL NO . 23I-2079                             \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                    CYS-A                                    \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                          INVENTORY MANAGEMENT SYSTEM                        \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m*************************************************************************************\033[0m\n";
        
        
       item i1(10 , "iron" , "iron id good in quality"          , 12 , 11000.0); 
       item i3(12 , "stove" , "stove id good in quality"        , 2  , 90000.0);
       item i4(9 , "bitter" , "bitter id good in quality"      , 1  , 22000.0);
      
      InventoryTree t1; 
     
       cout<<"\n\t\t\t\t\t\t\t\t\t\033[36m******ITEMS IN WAREHOUSE*****\033[0m\n";
       t1.insertItem(i1);
       t1.insertItem(i3);
       t1.insertItem(i4);
       
       
       t1.inorderToDisplay(t1.root);
        int option;
    
    do
    {
         cout<<"\n \t\t\t\t\t\t\t\033[35m-------- MENU FOR OPERATION IN INVENTORY MANAGEMENT SYSTEM ---------\n"
            << "\n\t\t\t\t\t\t\t 1- ADD ITEM \n"
            << "\n\t\t\t\t\t\t\t 2- Search Item \n"
            << "\n\t\t\t\t\t\t\t 3- Update Item \n"
            << "\n\t\t\t\t\t\t\t 4- Delete Item \n"
            << "\n\t\t\t\t\t\t\t 5- Stock Management Operations \n"
            << "\n\t\t\t\t\t\t\t 6- Price And Range Queries \n"
            << "\n\t\t\t\t\t\t\t 7- Bulk Insertion \n"
            << "\n\t\t\t\t\t\t\t 8- EXIT \033[0m\n";


string name ;
string des;
int q;
float p;

    cout<<"\nEnter your choice : ";
    cin>>option;
    
    switch( option)
    {
    
      case 1:
      {
      do 
      {
        cout << "\nEnter ID of item : ";
        cin >> id;

      if (t1.searchid(id)) 
      {
          cout << "\n\033[31m Item with "<<id<< " already exists. Please enter a unique ID.\033[0m\n";
      }
          } while(t1.searchid(id)); // Repeat until a unique ID is entered

      cout<<endl;
      cout<<"Enter Name of item : ";
      cin>>name;
      cout<<endl;
      cout<<"Enter  Description of item : ";
      cin>>des;
      cout<<endl;
      
      cout << "Enter Quantity of item : ";
      cin >> q;

      
      
      
      cout<<endl;
      cout<<"Enter Price of item : ";
      cin>>p;
      cout<<endl;
      
      item additem( id , name , des , q , p);
      t1.insertItem(additem);
      cout<<"\n\t\t\033[36m ITEM ADDED SUCCESSFULLY \033[0m \n";
     t1.inorderToDisplay(t1.root);
      break;
      }
      case 2:
      {
         cout<<"\n\nEnter the id of item you want to search : ";
         cin>>id;
         cout<<endl;
         treenode * getnode = NULL;
        getnode =  (t1.searchItemforUpdate(id));
        
        if( getnode!=NULL)
         {
             cout<<"\n\033[32m ITEM FOUND \033[0m\n"; 
             getnode->data.display();
         }
         
         else
         {
            cout<<"\n\033[31m NO ITEM AVAILABLE \033[0m\n";
         }
       break;
      }
      
      case 3:
      {
        cout<<"\nEnter the id of item you want to update : ";
        cin>>id;
        cout<<endl;
        treenode * getnode = NULL;
        getnode =  (t1.searchItemforUpdate(id));
        
        if( getnode!=NULL)
         {
         int choice;
         int q;          
         float p;
           cout<<" WHAT YOU WANT TO UPDATE :\n\n";
           cout<<" 1-Quantity \n";
           cout<<" 2-Price \n";
          
           cout<<" \n Select your choice :";
           cin>>choice;
          
          if( choice == 1 )
          {
          
            cout<<"\nEnter the New Quantity : ";
            cin>>q;
            
            t1.updateQuantity(getnode , q);
            cout<<endl;
            cout<<"\n\t\t\t\t\033[36m -----WAREHOUSE ITEMS AFTER UPDATING QUANTITY----- \033[0m\n";
            t1.inorderToDisplay(t1.root);
           } 
           else if( choice == 2 )
          {
          
            cout<<"\nEnter the New Price : ";
            cin>>p;
            
            t1.updateQuantity(getnode , p);
            cout<<endl;
            cout<<"\n\t\t\t\033[36m -----WAREHOUSE ITEMS AFTER UPDATING QUANTITY----- \033[0m\n";
            t1.inorderToDisplay(t1.root);
           } 
            
            else
            {
             cout<<"\n\033[31mInvalid choice \033[0m\n";
            }
               
         }
         
         else
         {
           cout<<"\n\n\033[31mNO ITEM FOUND \033[0m\n\n";
         }
       break;
      }
      case 4: {
    cout << "\nEnter ID of item: ";
    cin >> id;

    treenode *parent = t1.findParent(t1.root, id);
    treenode *targetNode = t1.searchItemforUpdate(id);
    
    if (targetNode != nullptr) 
    {
        if (parent == nullptr) 
        {
            
            t1.makeDeletion(t1.root);
        } 
        else if (parent->left == targetNode) 
        {
            t1.makeDeletion(parent->left);
        } 
        else if (parent->right == targetNode) 
        {
            t1.makeDeletion(parent->right);
        }
    }
     else 
     {
        cout << "\n\n\033[31m NO ITEM FOUND\033[0m" << endl;
    }

    cout << "\n\t\t\t\t\033[36m ----- WAREHOUSE ITEMS AFTER DELETION ----\033[0m\n";
    t1.inorderToDisplay(t1.root);
    break;
}
      case 5: 
      {
    int op; 
    do {
        cout << "\n OPERATIONS \n\n";
        cout << "1- Check Stock Availability \n\n";
        cout << "2- Low Stock Alert \n\n";
        cout << "3- Restock Item\n\n";
        cout << "4- Exit\n\n";
        cout << "Enter your choice: "; 
        cin >> op;
        switch (op) 
        {
            case 1:
                t1.checkstockAvailability();
                break;
            case 2:
                t1.itemslowinstock(t1.root);
                break;
            case 3:
            int no;
         cout<<"\n\nEnter the id of item you want to search : ";
         cin>>id;
         cout<<endl;
         if(t1.searchItem(id))
         {
            
        
            cout<<"Enter the amount of unit you want to add : ";
            cin>>no;
            cout<<endl;
            t1.restock( id , no);
         }
         
         else {
                cout<<"\n\nNO item available\n\n";}
                break;
            case 4:
                cout << "\n\n\t\tEXITING STOCK MANAGEMENT OPERATIONS...👋️\n";
                break;
            default:
                cout << "\n\033[31m Invalid choice. Please enter a valid option.\033[0m\n";
                break;
        }
    } while (op != 4); // Continue until user chooses to exit
    break;
}
      case 6:
      {
      int option;
      do
      {
      cout<<"\n1- List all items within a Price Range \n\n"
          <<"2- Cheapest Item \n\n"
          <<"3- Expensive Item \n\n"
          <<"4- Exit \n\n";
           cout << "Enter your choice: "; 
          cin>>option;
          switch(option)
          {
             case 1:
              cout<<"\n\t\tItems within a PRICE RANGE (1000-10,0000 ) :\n";
              t1.itemsWithPriceRange(t1.root);
              break;
              case 2 :
              t1.lowestPriceItem();
              break;
              case 3:
              t1.expensiveItem();
              break;
              case 4:
              cout<<"\n\033[32m EXIT \033[0m\n";
              break;
              default :
              cout<<"\n\033[31m Invalid option \033[0m\n";
              break;
          }
        
      }while(option!= 4);
       
        
        break;
      }
      case 7:
      {
          string filePath = "datass.txt";
         t1.bulkinsertion(filePath);
         cout<<"\n\t\t\t\033[36m -----WAREHOUSE ITEMS AFTER BULK INSERTION----- \033[0m\n";
            t1.inorderToDisplay(t1.root);
         
        break;
      }
      case 8:
      {
      cout<<"\n\033[32m EXITING \033[0m\n";
      break;
      }
      default:
      {
      cout<<"\n\033[31m INVALID CHOICE : Enter VALID Option/Choice \033[0m\n";
      break;
     }
    } // switch for main body
    
    }while(option!=8); // yeh main do ki while hai jis main add , delete update sab kaam hon gain*/
cout<<"\n\n";
   return 0;
}
